# TemperleyVC 🎙️

Bot de Discord para crear y administrar canales de voz temporales. Interfaz en español, comandos `/`, embeds decorados y botones para los controles principales. **Creador: AstridVMD**.

## Funciones incluidas

- Canal de entrada «crear VC»: al entrar, crea un canal de voz privado y mueve al usuario.
- Un rol de propietario y un rol de familia/confianza por canal. Los roles se crean al crear el VC y se eliminan junto con el canal temporal.
- Limpieza automática del canal y sus roles cuando queda vacío.
- Reclamar el canal si el propietario ya no está dentro.
- Familia de confianza: `/familia agregar` y `/familia quitar`.
- Comandos slash: `/configurar`, `/panel`, `/ayuda`, `/reclamar`, `/familia`, `/nombre`, `/limite`, `/bloquear`, `/ocultar`, `/transferir`, `/bitrate`, `/expulsar`, `/permitir`, `/denegar`.
- Panel de botones: bloquear/desbloquear, ocultar/mostrar, límite, invitar, expulsar, permitir, renombrar, bitrate, reclamar y transferir.
- Recursos visuales en `assets/branding` e `assets/icons`.

## Requisito importante: sin base de datos

TemperleyVC **no usa base de datos ni escribe datos de configuración en disco**. La configuración y el registro de canales activos viven solo en RAM. Por diseño, al reiniciar o redeplegar el proceso, esos datos se pierden. Si el bot se reinicia mientras quedan VC creados, no podrá reconocerlos para limpiarlos automáticamente; elimina manualmente esos canales huérfanos o vuelve a crear la configuración. Para que la configuración sobreviva reinicios sería necesario un almacenamiento persistente, que aquí se ha omitido a propósito.

Render puede suspender o reiniciar servicios según el tipo de servicio y el plan; este código no puede garantizar que un servicio gratuito permanezca siempre encendido. Consulta las condiciones actuales de Render y usa un servicio persistente/adecuado para bots de Discord.

## Instalación local

Requisitos: Node.js 20 o superior y npm.

```bash
npm install
cp .env.example .env
```

Rellena `.env`:

- `DISCORD_TOKEN`: token del bot, mantenlo secreto.
- `CLIENT_ID`: ID de la aplicación de Discord.
- `GUILD_ID`: ID del servidor para registrar comandos rápidamente.

En [Discord Developer Portal](https://discord.com/developers/applications), habilita el bot e invítalo al servidor con scopes `bot` y `applications.commands`. Permisos recomendados: Manage Channels, Manage Roles, View Channels, Connect, Speak, Move Members. El rol del bot debe estar por encima de los roles temporales que cree. No publiques el token ni lo subas a GitHub.

Después:

```bash
npm run deploy-commands
npm start
```

Usa `/configurar` como administrador para elegir el canal de voz de creación, categoría opcional y canal de panel opcional. Luego usa `/panel` para publicar los botones. La configuración hecha con `/configurar` solo dura mientras el proceso esté activo.

## Despliegue en Render

1. Sube el proyecto a un repositorio privado.
2. Crea un servicio tipo **Background Worker** (no un sitio web estático).
3. Build command: `npm install`
4. Start command: `npm start`
5. Añade las variables `DISCORD_TOKEN`, `CLIENT_ID`, `GUILD_ID` en Environment.
6. Ejecuta `npm run deploy-commands` localmente o como paso manual tras cambios de comandos.

No necesitas disco persistente ni base de datos. No configures un servicio web solo para mantenerlo despierto; el bot se conecta directamente a Discord Gateway.

## Permisos e intención

El bot utiliza `Guilds`, `GuildMembers` y `GuildVoiceStates`. En el portal de Discord, activa **Server Members Intent** si Discord lo requiere para tu aplicación. Los comandos de configuración requieren permisos de administrador o gestión de canales.

## Estructura

```text
TemperleyVC/
├── assets/
│   ├── branding/       # Icono del bot y referencia visual
│   └── icons/          # Iconos individuales y panel de controles
├── src/
│   ├── commands/       # Definición y ejecución de comandos slash
│   ├── utils/          # Embeds y gestión de VC
│   ├── config.js
│   ├── deploy-commands.js
│   ├── index.js
│   └── state.js        # Estado efímero en RAM
├── .env.example
├── package.json
└── README.md
```

## Notas

- Los comandos de bitrate están limitados por el máximo permitido al servidor y por el nivel de boost.
- Discord tiene límites en el número de roles del servidor y en la jerarquía de roles.
- Las interacciones de los botones que necesitan datos usan modales para pedirlos.
- No hay una garantía de uptime: depende de Render, Discord y la conexión.
